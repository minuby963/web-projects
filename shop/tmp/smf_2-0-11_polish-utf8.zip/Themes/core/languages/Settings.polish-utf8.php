<?php
// Version: 2.0 RC2; Settings

global $settings;

// Important! Before editing these language files please read the text at the top of index.english.php.
$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Domyślny styl poprzedniego wcielenia SMF, nazwa kodowa Core.<br /><br />Autor: The Simple Machines Team';

?>